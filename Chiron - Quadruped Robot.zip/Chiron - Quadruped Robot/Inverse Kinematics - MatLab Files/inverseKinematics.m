function updatePosition = inverseKinematics(X, Y, Z, usePrev)

    % Function to compute inverse kinematics for a 3-DOF robotic leg

    % This function calculates the joint angles (J1, J2, J3) needed to 
    % reach a Cartesian position (X_current + X, Y_Current_Y, Z_Current + Z).

    % INPUTS:
    %   X - Target position shift in the X-axis
    %   Y - Target position shift in the Y-axis
    %   Z - Target position in the Z-axis
    %
    % OUTPUT:
    %   updatePosition - A vector containing the joint angles [J1, J2, J3] in degrees
    
    persistent prevAngles prevPosition;



    % -------------------- CONSTANTS --------------------

    % Link lengths - Obtained from the CAD Model (in mm)
    L1 = 47.15;  % Center to Center Distance
    L2 = 81.6; 
    L3 = 103;

    % Rest position offsets (in mm) legs parallel to the floor & perpendicular to the body
    X_Rest =0;
    Y_Rest = 231.75;  % Default Y offset of the leg (max length as well)
    Z_Rest = 0; % Default Z offset of the leg (negative means below the base)

    % Mechanical offset for Joint 3 
    J3_LegAngle = 0; % Neglected



    % -------------------- INITIALIZATION --------------------

    if isempty(prevAngles) || ~usePrev
        % If no previous values exist, assume starting at rest position
        prevAngles = [90, 90, 180 - J3_LegAngle];
        prevPosition = [X_Rest, Y_Rest, Z_Rest];

    end



    % -------------------- APPLY OFFSETS --------------------

    % Adjust Y and Z coordinates to match the reference frame
    Y = Y + Y_Rest;
    Z = Z + Z_Rest;



    % -------------------- INVERSE KINEMATICS --------------------

    % Compute Joint 1 (Base rotation in the XY plane)
    % J1 determines how much the leg should rotate around the base
    J1 = atand(Y/X);

    % Compute the local coordinates
    X_Prime = sqrt(Y^2 + X^2) - L1;
    Z_Prime = Z;

    %Compute distance from J2 to th end of the foot
    R = sqrt(X_Prime^2 + Z_Prime^2);

    % Compute Joint 3 (Knee angle using the law of cosines)
    % This determines how much the knee needs to bend
    J3 = acosd((L2^2 + L3^2 - R^2) / (2 * L2 * L3));

    % Compute auxiliary angles for Joint 2 calculation
    B = acosd(((L2^2) + (R^2) - (L3^2)) / (2 * R * L2)); % Law of cosines
    A = atand(Z_Prime / X_Prime); % Angle due to height difference

    % Compute Joint 2 (Upper leg angle)
    % Since 'A' is negative at rest, we add it instead of subtracting
    J2 = B + A;



    % -------------------- UPDATE JOINT ANGLES --------------------

    % Convert angles to match servo orientation
    J1_final = J1; % Adjust to servo range
    J2_final = 90 + J2; % Adjust to servo range
    J3_final = J3 + J3_LegAngle; % Compensate for mechanical offset



    % -------------------- DISPLAY RESULTS --------------------

    fprintf('Moving from (%.1f, %.1f, %.1f) to (%.1f, %.1f, %.1f)\n', ...
            prevPosition(1), prevPosition(2), prevPosition(3), X, Y, Z);
    fprintf('New Joint Angles: J1=%.2f°, J2=%.2f°, J3=%.2f°\n', J1_final, J2_final, J3_final);



     % -------------------- STORE THE UPDATED VALUES --------------------

    prevAngles = [J1_final, J2_final, J3_final];  % Store the latest joint angles
    prevPosition = [X - X_Rest, Y - Y_Rest, Z - Z_Rest]; % Store the latest Cartesian position
    % Store the final angles
    updatePosition = prevAngles;


end