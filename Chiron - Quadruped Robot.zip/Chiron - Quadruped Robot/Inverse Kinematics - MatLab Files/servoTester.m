angles = inverseKinematics(0, -10, 0, false);
